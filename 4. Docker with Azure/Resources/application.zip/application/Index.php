<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="description" content="Displaying list of Courses">
    <meta http-equiv="refresh" content="10">
    <link rel="stylesheet" href="./lib/bootstrap/dist/css/bootstrap.min.css">
    <title>Courses</title>
</head>

<body>

<?php
$host_name = "mysql-instance";
$user = "appusr";
$password = "appusr@1090";
$database = "appdb";

$connection = new mysqli($host_name, $user, $password, $database);

if ($connection->connect_error) {
    die("<h3>Database Connection Failed: " . $connection->connect_error . "</h3>");
}

$query = "SELECT CourseID, ExamImage, CourseName, Rating FROM Course ORDER BY CourseID";
$result = $connection->query($query);
?>

<div class="container mt-4">

    <h1>Courses</h1>
    <p class="lead">This is a list of Courses</p>

    <table class="table table-striped table-bordered">
        <thead class="table-dark">
            <tr>
                <th>Course ID</th>
                <th>Course Image</th>
                <th>Course Name</th>
                <th>Rating</th>
            </tr>
        </thead>

        <tbody>

        <?php
        if ($result && $result->num_rows > 0) {

            while ($data = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($data['CourseID']) . "</td>";
                echo "<td><img src=\"" . htmlspecialchars($data['ExamImage']) . "\" width=\"400\" height=\"100\"></td>";
                echo "<td>" . htmlspecialchars($data['CourseName']) . "</td>";
                echo "<td>" . htmlspecialchars($data['Rating']) . "</td>";
                echo "</tr>";
            }

        } else {

            echo "<tr><td colspan='4' class='text-center'>No courses found.</td></tr>";

        }
        ?>

        </tbody>
    </table>

</div>

<?php
$connection->close();
?>

</body>
</html>